<?php

namespace App\Presenters;

use App\Helpers\Helper;

/**
 * Class DepreciationPresenter
 * @package App\Presenters
 */
class DepreciationPresenter extends Presenter
{

}
