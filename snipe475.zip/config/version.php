<?php
return array (
  'app_version' => 'v4.7.5',
  'full_app_version' => 'v4.7.5 - build 4118-g03a451240',
  'build_version' => '4118',
  'prerelease_version' => '',
  'hash_version' => 'g03a451240',
  'full_hash' => 'v4.7.5-10-g03a451240',
  'branch' => 'master',
);
